<!DOCTYPE html>
<html>
<head>
	
  

<style type="text/css">
	#contenair{
		height: 100%;
		width: 100%;

		
	}
	#r{
		margin-top: 5%;
		margin-bottom: 50px;
		margin-right: 20px;
		float: right;
		height:90%;
		width:45%;
		background-color: #3354FF;

		
	}
	#l
	{
		margin-top: 5%;
		margin-bottom: 50px;
		margin-left:30px;
		float: left;
		height: 90%;
		width: 45%;
		background-color: #3354FF;
		text-align: center;
	
	}
	body{
		color: #c7e617;
		font-size: 20px;
	}


	</style>
	
<script>
     
        function signup()
      {

          var alt="";
          var x=document.forms["signupform"]["firstname"].value;
          if (x==null || x=="")
            {
              alt +="First name must be filled out\n";
              
            
            }
         var y=document.forms["signupform"]["lastname"].value;
         if (y==null || y=="")
            {
              
              alt += "Last name must be filled out\n";
              
            }
			var x=document.forms["signupform"]["daytimephone"].value;
          if (x==null || x=="")
            {
              alt +="First name must be filled out\n";
              
            
            }
          var z=document.forms["signupform"]["email"].value;
          var atpos=z.indexOf("@");
          var dotpos=z.lastIndexOf(".");
              
           if (atpos<1 || dotpos<atpos+2 || dotpos+2>=z.length)
              {
             alt += "Not a valid e-mail address\n";
             
              }
         
          var v=document.forms["signupform"]["password1"].value; 
         
          if (v==null || v=="")
            {
              alt += "password must be filled out\n";
                 
            }
         var t=document.forms["signupform"]["password2"].value; 
         if (t==null || t=="")
            {
              alt += "confirm password must be filled out\n";
                
            }
			 if (v != t)
            {
              alt += "password  doesn't  match\n";
                 
            }
          if((document.forms["signupform"]["usertype1"].checked==false)&& (document.forms["signupform"]["usertype2"].checked==false))
      
            {
               alt += "payment type  must be filled out\n";
                     
            }
   
        if (alt != "")
             {
               alert(alt);
              return false;
             }
			 else {
			 	form.Submit()
			 }
}

     </script>
</head>
<body>
<div id="contenair">
<?php 
include('include/db_con.php');
	session_start();
if(isset($_POST['Submit']))
{
$fn=$_POST['firstname'];
$ln=$_POST['lastname'];
$phone=$_POST['daytimephone'];
$email=$_POST['email'];
$pass=$_POST['password1'];
$city=$_POST['city'];
$country=$_POST['country'];
$intr=$_POST['usertype'];

$query1="INSERT INTO users (first_name,last_name,day_phone,user_name,user_password,city,country,payment_type)VALUES('".$fn."','".$ln."','".$phone."','".$email."','".$pass."','".$city."','".$country."','".$intr."')";
if (!mysqli_query($con,$query1))
  {
  echo("Error description: " . mysqli_error($con));
  }
}
?>
<?php 
		if (isset($_POST['username'],$_POST['password']))
			   {
                $username=$_POST['username'];
                $password=$_POST['password'];
  
                   if (empty($username) || empty($password))
                   {
                      $error = 'Hey All fields are required!!';
                    }
                     
					 else {  
					 $login="select * from users where user_name='".$username."' and user_password ='".$password."'";
					 $result=mysqli_query($con,$login);
					if(mysqli_fetch_array($result,MYSQLI_NUM)){
				 $_SESSION['logged_in']='true';
				 $_SESSION['username']=$username;
					 header('Location:registration.php');
					 exit();
					 } else {
					 $error='Incorrect details !!';
					 }
					       }
		}
  
  ?>
  <div>
<h2 align="center" style="color:green"><b><u>TABLE BOOKING</u></center></b></h2>
</div>
  <div id="l" align="left">
<h2  align="center" style="color:red"><b><u>WELCOME TO FOOD KING</u></b> </h2>
<h3 align="center"><u><i> If You Are New to this Restaurant.... </i></u></h3>
<h3 align="center"><u><i>Create A New Account Below...</i></u></h3>
<table align="center">
 <form method="POST" name="signupform" action="index.php" onSubmit="return signup();" >
	 <tr>
		<td height="40"><b>FirstName:</b></td>
		<td><input name="firstname" type="text" id="firstname" size="40" />
		
		</td>
	</tr>
	<tr>
		<td height="40"><b>LastName:</b></td>
		<td><input name="lastname" type="text" id="lastname" size="40"  />
		
		</td>
	</tr>
	<tr>
		<td height="40"><b>Phone:</b></td>
		<td><input name="daytimephone" type="text" id="daytimephone" size="40" class="phone" />
		
		</td>
	</tr>
	<tr>
		<td height="40"><b>E-mail:</b></td>
		<td><input name="email" type="text" id="email" size="40"  />
		
		</td>
	</tr>
	
	<tr>
		<td height="40"><b>Password:</b></td>
		<td><input name="password1" type="password" id="password1" size="40" />
		
		</td>
	</tr>
	<tr>
		<td height="40"><b>Confirm Password:</b></td>
		<td><input name="password2" type="password" id="password2" size="40" />
		
		</td>
	</tr>
    <br>
	<tr>
		<td height="40"><b>City/State</b></td>
		<td><input name="city" type="text" id="city" size="40"  />
		</td>
	</tr>
    <br>
	<tr>
		
		<td height="40"><b>Country</b></td>
		<td><input name="country" type="text" id="country" size="40" />
		
		</td>
		
	</tr>
    <br>
    
	<tr>
		<td><b>Payment Type:</b></td>
		<td><input type="radio" name="usertype" id="usertype1" value="cash" /><b>Cash</b>
		<input type="radio" name="usertype" id="usertype2" value="paypal" /><b>Paypal/CreditCard</b>
		</td>
	</tr>
	<tr>
	<td align="center" colspan="2"><input type="submit" name="Submit" value="Submit" />
		<input type="reset" name="reset" value="Reset"  /></td></tr>
    </form>
   </table><br><br><br><br>
</div>
	 
   
     <div id="r" align="right">
	<form action="index.php" method="POST">
		<h3 align="center" id="h"><u><i>If U Are Existing Member</i></u></h3>
	<h2 align="center" id="h"><u><i>Login Here........</i></u></h2>
        <table align="center" id="t">
		<tr> <?php  if (isset($error)) {?>
           <small style="color:#aa0000;"><?php echo $error; ?>
            <br /> <br />
           <?php } ?> </tr>
          <tr>
            <td width="113"><b>Email:</b></td>
            <td width="215">
              <input name="username" type="text"  size="40" /></td>
          </tr>
          <tr>
            <td><b>Password:</b></td>
            <td>
              <input name="password" type="password"  size="40" /></td>
          </tr>
          <tr>
            <td colspan="2" align="center">
			<input type="submit" name="sub" value="Login" /></td>
            </tr>
			
       </table><br><br><br>
      <center><h2><b> Login Here To Book Your Table And Enjoy The Food...</b></h2></center>
      <br><br><br><br><br>
     
		
		
	</div>

       
		
		
	</div>
    </div>
  </div>
</div>
</body>
</html>