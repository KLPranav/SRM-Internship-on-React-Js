

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";



--
-- Database: `assignment`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabledetail`
--

DROP TABLE IF EXISTS `tabledetail`;
CREATE TABLE IF NOT EXISTS `tabledetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `present_date` date NOT NULL,
  `booked_date` date NOT NULL,
  `table_type` varchar(50) NOT NULL,
  `no_of_tables` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabledetail`
--

INSERT INTO `tabledetail` (`id`, `username`, `present_date`, `booked_date`, `table_type`, `no_of_tables`, `amount`) VALUES
(2, 'chebrolurukmini@gmail.com', '2020-08-10', '2020-08-11', '250', '5', '1250');

-- --------------------------------------------------------

--
-- Table structure for table `tabletype`
--

DROP TABLE IF EXISTS `tabletype`;
CREATE TABLE IF NOT EXISTS `tabletype` (
  `table_id` int(11) NOT NULL AUTO_INCREMENT,
  `table_type` varchar(50) NOT NULL,
  `table_price` varchar(50) NOT NULL,
  `table_class` varchar(50) NOT NULL,
  PRIMARY KEY (`table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabletype`
--

INSERT INTO `tabletype` (`table_id`, `table_type`, `table_price`, `table_class`) VALUES
(1, 'AC', '1', 'low class'),
(2, 'AC', '2', 'high class'),
(3, 'NON AC', '1', 'low class'),
(4, 'NON AC', '1', 'high class'),
(5, 'Special', '2', 'low class'),
(6, 'Special', '3', 'high class');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `day_phone` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `payment_type` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `day_phone`, `user_name`, `user_password`, `city`, `country`, `payment_type`) VALUES
(1, 'Rukmini', 'Chebrolu', '9505918828', 'chebrolurukmini@gmail.com', 'chebrolu', 'Vijayawada', 'India', 'paypal');
COMMIT;




