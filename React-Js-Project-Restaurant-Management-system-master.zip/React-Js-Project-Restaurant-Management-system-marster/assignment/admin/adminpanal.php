<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title></head>

<body>
 
	  <h1>Welcome Admin</h1>
	  Choose option from Below to take action!!!!
	  Create new Booking click <a href="../registration.php"> Here</a>
	  <?php
	  include('../include/db_con.php');
	  $sql="select * from tabledetail ";
	  $row=mysqli_query($con,$sql);
	 
	  ?><table border="1">
	  <?php
	  
	  while($data=mysqli_fetch_array($row,MYSQLI_ASSOC))
	  {
	  ?>
	  <tr>
	  <td><?php echo $data[id]; ?></td>
	  <td><?php echo $data[username]; ?></td>
	  <td><?php echo $data[present_date]; ?></td>
	  <td><?php echo $data[booked_date]; ?></td>
	  <td><?php echo $data[table_type]; ?></td>
	  <td><?php echo $data[no_of_tables]; ?></td>
	  <td><?php echo $data[amount]; ?></td>
	  <td><a href="update.php?id=<?php echo $data[id]; ?>">update</a></td>
	  <td><a href="delete.php?id=<?php echo $data[id]; ?>">delete</a></td>
	  </tr>
	  <?php
	  }
	  
	  
	  ?>
	  </table>
	  
	  </div>
</body>
</html>
