<!DOCTYPE html>
<html>
<head>
<style type="text/css">
	#contenar{
		height: 100%;
		width: 100%;
		
	}
	#r{
		margin-top: 5%;
		margin-bottom: 5%;
		margin-right: 5%;
		margin-left: 5%;
		float: center;
		background-color: #b7bcbd;
		
	}

	</style>
	

     
</head>

<body>
<?php
include('../include/db_con.php');
session_present();
if(isset($_POST['sub']))
{
$username=$_POST['username'];
$tabletype=$_POST['field_1'];
$presentdate=$_POST['presentdate'];
$bookeddate=$_POST['bookeddate'];
$table_nos=$_POST['table_nos'];
$amount=$_POST['tableprice'];
$id = $_POST['id'];

$checktable= "select count(*) from tabledetail where table_type='".$tabletype."' ";
$check=mysqli_query($con,$checktable);
$tablecount=mysqli_fetch_array($check,MYSQLI_ASSOC);
 $checkcount=$tablecount[0];
if($checkcount>=10)
{
?> <script>alert("Sorry tables are not Available :( please try another Option !!");</script>
<?php }
else{
$sql1="UPDATE tabledetail set username='".$username."',present_date='".$presentdate."',booked_date='".$bookeddate."',table_type='".$tabletype."',no_of_tables='".$table_nos."',amount='".$amount."' where id='".$id."'";
mysqli_query($con,$sql1);
header("location:adminpanal.php");
}
}
?>

<div id="contenar">
<?php
if(isset($_GET['id']))
{
$id=$_GET['id'];
$getdata= "select * from tabledetail where id='".$id."' ";
$check1=mysqli_query($con,$getdata);
$table=mysqli_fetch_array($check1,MYSQLI_ASSOC);
}
?>
	<div id="r">
	<form action="update.php" method="POST">
	<h2 align="center" id="h"><u><i>Book table</i></u></h2>
	<h3> Welcome <?php session_present(); if(isset($_SESSION['username'])){ echo $_SESSION['username']; } if(isset($_GET['id'])){ echo $table['username']; }  ?> !!!</h3>
        <table >
		
          <tr>
            <td width="113">Present Date</td>
            <td width="215">
			<?php if(isset($_GET['id'])){ ?>
			 <input name="tableid" type="hidden"  value="<?php if(isset($_GET['id'])){ echo $_GET['id']; }  ?>" /> <?php } ?>
              <input name="presentdate1" type="date"  value="<?php if(isset($_POST['presentdate1'])){ echo $_POST['presentdate1']; } if(isset($_GET['id'])){ echo $table['present_date']; }  ?>" /></td>
          </tr>
          <tr>
            <td>Booked Date</td>
            <td>
              <input name="bookeddate1" type="date" value="<?php if(isset($_POST['bookeddate1'])){ echo $_POST['bookeddate1']; }if(isset($_GET['id'])){ echo $table['booked_date']; }  ?>" onchange='this.form.submit()' /></td>
          </tr>
			
       </table>
		</form>
		<form action="update.php" method="POST">
        <table >
		<?php if(isset($_POST['tableid'])){ ?>
			 <input name="id" type="hidden"  value="<?php if(isset($_POST['tableid'])){ echo $_POST['tableid']; }  ?>" /> <?php } ?>
          <tr>
            <td width="113"></td>
            <td width="215">
              <input name="presentdate" type="hidden" value="<?php if(isset($_POST['presentdate1'])){ echo $_POST['presentdate1'];  } if(isset($_GET['id'])){ echo $table['present_date']; }?>" /></td>
          </tr>
          <tr>
            <td></td>
            <td><input name="username" type="hidden" value="<?php session_present(); if(isset($_SESSION['username'])){ echo $_SESSION['username']; } if(isset($_GET['id'])){ echo $table['username']; }  ?>"  />
              <input name="bookeddate" type="hidden" value="<?php if(isset($_POST['bookeddate1'])){ echo $_POST['bookeddate1']; } if(isset($_GET['id'])){ echo $table['booked_date']; }?>"  /></td>
          </tr>
		  <tr>
            <td>Table Type </td>
            <td>
              <select class="text_select" id="field_1" name="field_1" >  
<option value="00">- Select -</option>   
<?php if(isset($_POST['presentdate1'])){
$paymentDate = $_POST['presentdate1'];
$contractDateBegin = '2013-12-20';
$contractDateEnd ='2014-03-25';

if (($paymentDate >= $contractDateBegin) && ($paymentDate <= $contractDateEnd))
{
 $s2="select * from tabletype where table_class ='high class' ";
$s3=mysqli_query($con,$s2);
}
else
{
$s2="select * from tabletype where table_class='low class' ";
$s3=mysqli_query($con,$s2);
}


?>
<?php while($catdata=mysqli_fetch_array($s3,MYSQLI_ASSOC)) { ?>  <option value="<?php echo $catdata['table_price']; ?>"><?php echo $catdata['table_type']; ?></option>
           <?php } ?>
		   <?php } ?>
           </select></td>
          </tr>
		  <tr>
            <td>Price per table</td>
            <td>
             <span id="a1"><?php if(isset($_GET['id'])){ echo $table['table_type']; }?></span>$
           </td>
          </tr>
		   <tr>
            <td>No. of Guest per table</td>
            <td>
              <input name="guest" type="text " value="<?php if(isset($_GET['id'])){ echo $table['no_of_tables']; }?>" size="10"/></td>
          </tr>
		  <tr>
            <td>No. of tables </td>
            <td>
              <input name="table_nos" id="table_nos" type="text " value="<?php if(isset($_GET['id'])){ echo $table['no_of_tables']; }?>" size="10" onChange="gettotal1()" /></td>
          </tr>
		  <tr>
            <td>Total Amount To Pay</td>
            <td>
             <input type="text" name="tableprice" id="total1" value="<?php if(isset($_GET['id'])){ echo $table['amount']; }?>"  size="10px" readonly="" />
           </td>
          </tr>
		  
          <tr>
            <td colspan="2" align="center">
			<input type="submit" name="sub" value="Pay & Book" /></td>
            </tr>
			
       </table>
		</form>
		
		<script language="javascript" type="text/javascript">
function notEmpty(){

var e = document.getElementById("field_1");
var strUser = e.options[e.selectedIndex].value;
 var strUser=document.getElementById('a1').innerHTML=strUser;




}
notEmpty()
    
    document.getElementById("field_1").onchange = notEmpty;


   function gettotal1(){
      var pricepertable=document.getElementById('a1').innerHTML;
      var tablenos=document.getElementById('table_nos').value;
      var totalamount=parseFloat(pricepertable)* parseFloat(tablenos);
			
      document.getElementById('total1').value=totalamount;
	
   }
			</script>
 
		
	</div>
</div>
</body>
</html>