<!DOCTYPE HTML>
<html>
<head>
<style type="text/css">
	#contenair{
		height: 100%;
		width: 100%;
		
	}
	#r{
		margin-top: 15%;
		margin-bottom: 5%;
		
		height:95%;
		
		background-color: #3354FF;
		
	}
	body{
		font-size: 25px;
	}

	</style>
	

</head>
<body>
<div id="contenair">
	<div id="r" >
	
	<?php 
	include('../include/db_con.php');
	session_start();
		if (isset($_POST['username'],$_POST['password']))
			   {
                $username=$_POST['username'];
                $password=$_POST['password'];
  
                   if (empty($username) || empty($password))
                   {
                      $error = 'Hey All fields are required!!';
                    }
                     
					 else {  
					 $login="select * from users where user_name='".$username."' and user_password ='".$password."'";
					 $result=mysqli_query($con,$login);
					
				
					 
					if(mysqli_fetch_array($result,MYSQLI_ASSOC)){
				 $_SESSION['logged_in']='true';
				 $_SESSION['username']=$username;
					 header('Location:adminpanal.php');
					 exit();
					 } else {
					 $error='Incorrect details !!';
					 }
					       }
		}
  
  ?>
	<form align="center" action="index.php" method="POST">
		<h2 align="center" id="h"><u><i>Hello, Admin</i></u></h2>
	<h2 align="center" id="h"><u><i>Login Here........</i></u></h2>

        <table align="center">
		<tr> <?php  if (isset($error)) {?>
           <small style="color:#green;"><?php echo $error; ?>
            <br /> <br />
           <?php } ?> </tr>

  

         <tr>
            <td width="113"><b>Email:</b></td>
            <td width="215">
              <input name="username" type="text"  size="40" /></td>
          </tr>
          <tr>
            <td><b>Password:</b></td>
            <td>
              <input name="password" type="password"  size="40" /></td>
          </tr>
          <tr>
            <td colspan="2" align="center">
			<input type="submit" name="sub" value="Login" /></td>
            </tr>
			
       </table>
		</form>
		
		
	</div>
</div>
</body>
</html>