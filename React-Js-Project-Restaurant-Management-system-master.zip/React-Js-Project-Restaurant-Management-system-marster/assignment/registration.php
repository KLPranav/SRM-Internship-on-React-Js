<!DOCTYPE html>
<html>
<head>
<style type="text/css">
	#contenar{
		height: 100%;
		width: 100%;
		
	}
	#r{
		margin-top: 5%;
		margin-bottom: 5%;
		margin-right: 5%;
		margin-left: 5%;
		float: center;
		background-color: #b7bcbd;
		
	}

	</style>
	

     
</head>

<body>
<?php
include('include/db_con.php');
session_start();
if(isset($_POST['sub']))
{
$username=$_POST['username'];
$roomtype=$_POST['field_1'];
$presentdate=$_POST['presenttdate'];
$bookeddate=$_POST['bookeddate'];
$table_nos=$_POST['table_nos'];
$amount=$_POST['roomprice'];

$checktable= "select count(*) from tabledetail where table_type='".$tabletype."' ";
$check=mysqli_query($con,$checktable);
$tablecount=mysqli_fetch_array($check,MYSQLI_NUM);
 $checkcount=$tablecount[0];
if($checkcount>=10)
{
?> <script>alert("Sorry Tables Are not Available :( please try another Option !!");</script>
<?php }
else{
$s1="INSERT INTO tabledetail (username,present_date,booked_date,table_type,no_of_tables,amount)VALUES('".$username."','".$presenttdate."','".$bookeddate."','".$tabletype."','".$table_nos."','".$amount."')";
mysqli_query($con,$s1);
header("location:registration.php?success=true");
}
}
?>

<div id="contenar">

	<div id="r">
	<form action="registration.php" method="POST">
	<h2 align="center" id="h"><u><i>Book A Table</i></u></h2>
	<h3> Welcome   <?php session_start(); if(isset($_SESSION['username'])){ echo $_SESSION['username']; } ?> !!!</h3>
	<?php if(isset($_GET['success'])){
		echo '<h4> Your Table Booked successfully, See You soon.... !!!</h4>';
	}?>
        <table >
		
          <tr>
            <td width="113">Today's Date</td>
            <td width="215">
              <input name="presentdate1" type="date"  value="<?php if(isset($_POST['presentdate1'])){ echo $_POST['presentdate1']; }?>" /></td>
          </tr>
          <tr>
            <td>Checkin Date</td>
            <td>
              <input name="bookeddate1" type="date" value="<?php if(isset($_POST['enddate1'])){ echo $_POST['bookeddate1']; }?>" onchange='this.form.submit()' /></td>
          </tr>
			
       </table>
		</form>
		<form action="registration.php" method="POST">
        <table >
		
          <tr>
            <td width="113"></td>
            <td width="215">
              <input name="presentdate" type="hidden" value=" <?php if(isset($_POST['presentdate1'])){ echo $_POST['presentdate1']; }?> " /></td>
          </tr>
          <tr>
            <td></td>
            <td><input name="username" type="hidden" value="<?php session_start(); if(isset($_SESSION['username'])){ echo $_SESSION['username']; } ?>"  />
              <input name="bookeddate" type="hidden" value=" <?php if(isset($_POST['bookeddate1'])){ echo $_POST['bookeddate1']; }?> "  /></td>
          </tr>
		  <tr>
            <td>Table Area</td>
            <td>
              <select class="text_select" id="field_1" name="field_1" >  
<option value="00">- Select -</option>   
<?php if(isset($_POST['presentdate1'])){
$paymentDate = $_POST['presentdate1'];
$contractDateBegin = '2013-12-20';
$contractDateEnd ='2014-03-25';

if (($paymentDate >= $contractDateBegin) && ($paymentDate <= $contractDateEnd))
{
 $s2="select * from tabletype where table_class ='high class' ";
$s3=mysqli_query($con,$s2);
}
else
{
$s2="select * from tabletype where table_class='low class' ";
$s3=mysqli_query($con,$s2);
}


?>
<?php while($catdata=mysqli_fetch_array($s3,MYSQLI_ASSOC)) { ?>  <option value="<?php echo $catdata['table_price']; ?>"><?php echo $catdata['table_type']; ?></option>
           <?php } ?>
		   <?php } ?>
           </select></td>
          </tr>
		  <tr>
            <td>Price per Table</td>
            <td>
             <span id="a1"  ></span>₹
           </td>
          </tr>
		   <tr>
            <td>No. of Guest per Table</td>
            <td>
              <input name="guest" type="text " size="10"/></td>
          </tr>
		  <tr>
            <td>No. of Tables </td>
            <td>
              <input name="table_nos" id="table_nos" type="text " size="10" onChange="gettotal1()" /></td>
          </tr>
		  <tr>
            <td>Total Amount To Pay</td>
            <td>
             <input type="text" name="tableprice" id="total1"  size="10px" readonly="" />
           </td>
          </tr>
		  
          <tr>
            <td colspan="2" align="center">
			<input type="submit" name="sub" value="Pay & Book" /></td>
            </tr>
			
       </table>
		</form>
		
		<script language="javascript" type="text/javascript">
function notEmpty(){

var e = document.getElementById("field_1");
var strUser = e.options[e.selectedIndex].value;
 var strUser=document.getElementById('a1').innerHTML=strUser;




}
notEmpty()
    
    document.getElementById("field_1").onchange = notEmpty;


   function gettotal1(){
      var gender1=document.getElementById('a1').innerHTML;
      var gender2=document.getElementById('table_nos').value;
      var gender3=parseFloat(gender1)* parseFloat(gender2);
			
      document.getElementById('total1').value=gender3;
	
   }
			</script>
 
		
	</div>
</div>
</body>
</html>